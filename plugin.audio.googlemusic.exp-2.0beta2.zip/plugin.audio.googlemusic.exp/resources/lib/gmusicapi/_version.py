# -*- coding: utf-8 -*-

__version__ = u"12.0.1-rc.1"
